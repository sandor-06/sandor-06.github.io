function randomPage() {

let x = Math.floor((Math.random() * 14) + 1);

if (x === 1) {
window.location.assign("angelina.html");
}


if (x === 2) {
window.location.assign("ben.html");
}


if (x === 3) {
window.location.assign("cruz.html");
}


if (x === 4) {
window.location.assign("dakota.html");
}


if (x === 5) {
window.location.assign("farranika.html");
}


if (x === 6) {
window.location.assign("fredi.html");
}


if (x === 7) {
window.location.assign("haotian.html");
}


if (x === 8) {
window.location.assign("melisa.html");
}


if (x === 9) {
window.location.assign("oliver.html");
}


if (x === 10) {
window.location.assign("quince.html");
}


if (x === 11) {
window.location.assign("theo.html");
}


if (x === 12) {
window.location.assign("vivianne.html");
}


if (x === 13) {
window.location.assign("zhumabek.html");
}


if (x === 14) {
window.location.assign("zoey.html");
}


if (x === 15) {
window.location.assign(".html");
}


if (x === 16) {
window.location.assign(".html");
}



}
